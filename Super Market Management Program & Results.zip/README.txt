ReadMe File for SuperMarket Management Program:

Done by NIRANJAN.K
Sri Sairam Engineering College, Chennai-44.

Programming Language used: "Python".

Software Needed to run the program: "Python 3.6" (latest version) link: "https://www.python.org/ftp/python/3.6.1/python-3.6.1.exe"
Software Needed to view the output: Any Web Browser. Browser which supports HTML5 is recommended to get the proper result. Here I have used "Google Chrome".

The following libraries are installed by "pip install" method..
1)click 6.7        [inbuilt]
2)MarksupSafe 1.0  [inbuilt]
3)virtualenv 15.1.0[downloaded and installed]
4)Flask 0.12.1     [downloaded and installed]
5)itsdangerous 0.24[automatically downloaded while downloading Flask]
6)Werkzeug 0.12.1  [automatically downloaded while downloading Flask]
7)Jinja2 2.9.6     [automatically downloaded while downloading Flask]

Example: To install a package: open command prompt, type "pip install Flask.py", will download and install automatically.

To view the installed packages type "pip freeze". Command Prompt will display the libraries installed.

This Program is created for Super Market Management Purposes. The program is created for a sample of 10 items. If Additional items are need to be Added , Slight modifications in the program is to be made.

This Program can be executed on multiple devices simultaneously. The devices should be on the same interconnected network. The devices can also be connected in WiFi. Only one device acts as a server. So it is enough that "Python 3.6" software is installed in that particular device alone. 

In this program, I have added an Smtp mail option. We can order items by sending mail. I have inserted my mail ID for testing purpose. To check its working, You need to add your mail ID in receievers variable.

Two Displays are connected to a single system. One is for Biller and another one is for the Customer. Both Display displays the same View.

After Running the program, To View the output,  Open Chrome Browser and type "localhost:5000" in Address bar and press Enter.
To view another devices , Open Browser and type " [ServerSystemIP]:5000" in Address bar and press Enter. 

After clicking the "Print Bill" option , the printout is printed by pressing "Ctrl+P" combination.  

Thanks for reading this file. 


